import "./App.css";
import { Field } from "./components/Field"

function App() {
	return (
		<div className="App">
			<header className="App-header">
				<Field />
			</header>
		</div>
	);
}

export default App;
