
export const RESET_SQUARES = {
	type: "RESET_SQUARES"
}
