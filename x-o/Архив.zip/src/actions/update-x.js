
export const updateX = (isXNext) => {

	return {
		type: 'UPDATE_X',
		payload: isXNext
	}
}
