
export const updateSquares = (newSquares) => {
	return {
		type: 'UPDATE_SQUARES',
		payload: newSquares
	}
}
